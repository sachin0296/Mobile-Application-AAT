<?php
if(isset($_POST['submit'])){
    $to = 'info@zikshana.com';
    $firstname = $_POST["Name"];
    $email= $_POST["Email"];
	$grade= $_POST["Grade"];
	$school= $_POST["School"];
    $phone= $_POST["Phone"];
    


    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= "From: " . $email . "\r\n"; // Sender's E-mail
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

    $message ='<table style="width:100%">
        <tr>
            <td>'.$firstname.'  '.$laststname.'</td>
        </tr>
        <tr><td>Email: '.$email.'</td></tr>
        <tr><td>Grade: '.$grade.'</td></tr>
		<tr><td>School: '.$school.'</td></tr>
		<tr><td>phone: '.$phone.'</td></tr>
        
    </table>';

    if (@mail($to, $email, $message, $headers))
    {
        echo 'The message has been sent.';
    }else{
        echo 'failed';
		}
}

?>
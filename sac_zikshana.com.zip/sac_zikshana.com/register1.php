
<?php
     if(isset($_POST['submit']))
     {
        $my_user = "root";
        $my_password = "";
        $my_db ="joinus";
        $con = mysqli_connect("localhost",$my_user,$my_password);
        // Check connection
        mysqli_select_db($con,$my_db)or die("cannot select DB");
        $Name = $_POST["Name"];
		$Occupation = $_POST["Occupation"];
		$Email = $_POST["email"];
		$Contact = $_POST["phoneno"];
        $Address = $_POST["Address"];
		$Message = $_POST["Message"];
        
        $sql="insert into register(name,occupation,email,contact,address,message) VALUES('$Name','$Occupation','$Email','$Contact','$Address','$Message')";
        if (mysqli_query($con, $sql))
        {
            echo ("<script LANGUAGE='JavaScript'>
			window.alert('REGISTERED SUCCESSFULLY');
			window.location.href='index.html';
			</script>");
        } 
        else
        {
            echo ("<script LANGUAGE='JavaScript'>
    window.alert('Email aleardy registered');
    window.location.href='digital-marketing-certifications-in-belgaum.html';
    </script>");
        }
        mysqli_close($con);
     }
?>